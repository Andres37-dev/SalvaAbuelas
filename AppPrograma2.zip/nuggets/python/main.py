# program_camera_debug.py

import cv2
from collections import deque
import time

import FallDetectorMovenetArduino as fall_detector


# Config _______________________________________________________________________

# How long the user can be absent before we consider it an anomaly.
# Currently only printed for debugging.
PRESENCE_TIMEOUT = 12 * 3600


# Cámara _______________________________________________________________________

class FallDetector:

    def __init__(self, camera_device=None):

        # If a specific camera is provided, use only that one.
        # Otherwise, try /dev/video0 through /dev/video3.
        if camera_device is not None:
            self.camera_devices = [camera_device]
        else:
            self.camera_devices = [
                "/dev/video0",
                "/dev/video1",
                "/dev/video2",
                "/dev/video3",
            ]
    
        self.camera_device = None


        self.fps = fall_detector.FPS
        self.frame_interval = 1.0 / self.fps

        self.states = deque(maxlen=fall_detector.WINDOW)

        self.crop_region = None
        self.image_height = None
        self.image_width = None

        self.last_processed = 0.0

        # Evita imprimir continuamente mientras la misma caída
        # sigue siendo detectada en varios frames consecutivos.
        self.previous_fall_detected = False

    def open(self):

        print("Opening camera...")
    
        for camera_device in self.camera_devices:
    
            print(f"Trying camera device: {camera_device}")
    
            cap = cv2.VideoCapture(camera_device)
    
            # --------------------------------------------------------------
            # Check whether OpenCV managed to open the device.
            # --------------------------------------------------------------
    
            if not cap.isOpened():
    
                print(
                    f"Could not open camera device {camera_device}"
                )
    
                cap.release()
                continue
    
            # --------------------------------------------------------------
            # Opening the device isn't enough.
            # Try reading an actual frame.
            # --------------------------------------------------------------
    
            ret, frame = cap.read()
    
            if not ret or frame is None:
    
                print(
                    f"Camera {camera_device} opened, "
                    f"but could not read a frame."
                )
    
                cap.release()
                continue
    
            # --------------------------------------------------------------
            # Camera works.
            # --------------------------------------------------------------
    
            self.camera_device = camera_device
    
            print()
            print(
                f"Camera opened successfully: "
                f"{camera_device}"
            )
    
            self.image_height, self.image_width = frame.shape[:2]
    
            print(
                f"Camera resolution: "
                f"{self.image_width}x{self.image_height}"
            )
    
            self.crop_region = fall_detector.init_crop_region(
                self.image_height,
                self.image_width,
            )
    
            print("Crop region initialized.")
            print("Starting image processing...")
            print()
    
            return cap, frame
    
        # ------------------------------------------------------------------
        # None of the cameras worked.
        # ------------------------------------------------------------------
    
        raise RuntimeError(
            "Could not open any camera device. "
            "Tried: "
            + ", ".join(self.camera_devices)
        )


    def process_frame(self, frame):

        """
        Same image-processing logic as FallDetectorMovenet.
        No MQTT is involved here.
        """

        now = time.time()

        # Limit processing to configured FPS.
        if now - self.last_processed < self.frame_interval:
            return None, False

        self.last_processed = now

        # Get current image dimensions.
        image_height, image_width = frame.shape[:2]

        # In case the camera resolution changes.
        if (
            self.image_height != image_height
            or self.image_width != image_width
            or self.crop_region is None
        ):
            print(
                "Camera resolution changed. "
                "Reinitializing crop region."
            )

            self.image_height = image_height
            self.image_width = image_width

            self.crop_region = fall_detector.init_crop_region(
                image_height,
                image_width,
            )

        # ------------------------------------------------------------------
        # Convert OpenCV BGR image to RGB.
        # ------------------------------------------------------------------

        rgb = cv2.cvtColor(
            frame,
            cv2.COLOR_BGR2RGB
        )

        # Convert image to TensorFlow tensor.
        tf_frame = fall_detector.tf.convert_to_tensor(rgb)

        # ------------------------------------------------------------------
        # MoveNet inference.
        # ------------------------------------------------------------------

        keypoints_with_scores = fall_detector.run_inference(
            fall_detector.movenet,
            tf_frame,
            self.crop_region,
            crop_size=[
                fall_detector.input_size,
                fall_detector.input_size,
            ],
        )

        # ------------------------------------------------------------------
        # Update crop region using detected person.
        # ------------------------------------------------------------------

        self.crop_region = fall_detector.determine_crop_region(
            keypoints_with_scores,
            image_height,
            image_width,
        )

        # Store current detection.
        self.states.append(keypoints_with_scores)

        # ------------------------------------------------------------------
        # Analyze temporal information.
        # ------------------------------------------------------------------

        if len(self.states) >= 2:

            state = fall_detector.analyze_keypoints(
                list(self.states)
            )

        else:

            state = {
                "user_in_frame": False,
                "fall_detected": False,
            }

        return state, True

    def should_report_fall(self, state):

        """
        Returns True only when a new fall is detected.

        This prevents printing the same fall on every frame.
        """

        fall_detected = bool(
            state.get("fall_detected", False)
        )

        new_fall = (
            fall_detected
            and not self.previous_fall_detected
        )

        self.previous_fall_detected = fall_detected

        return new_fall

    def reset(self):

        self.states.clear()
        self.crop_region = None
        self.previous_fall_detected = False


# Main ________________________________________________________________________

def main():

    detector = FallDetector()

    cap = None

    try:

        # ------------------------------------------------------------------
        # Open camera.
        # ------------------------------------------------------------------

        cap, first_frame = detector.open()

        print()
        print("Camera debug program running.")
        print()

        # ------------------------------------------------------------------
        # Process first frame.
        # ------------------------------------------------------------------

        state, processed = detector.process_frame(
            first_frame
        )

        # ------------------------------------------------------------------
        # Main camera loop.
        # ------------------------------------------------------------------

        while True:

            # Read frame.
            ret, frame = cap.read()

            if not ret:

                print(
                    "ERROR: Could not read frame from camera."
                )

                break

            # --------------------------------------------------------------
            # Process image.
            # --------------------------------------------------------------

            state, processed = detector.process_frame(
                frame
            )

            if not processed:
                continue

            # --------------------------------------------------------------
            # Get detection information.
            # --------------------------------------------------------------

            user_in_frame = bool(
                state.get("user_in_frame", False)
            )

            fall_detected = bool(
                state.get("fall_detected", False)
            )

            fall_reasons = state.get(
                "fall_reasons",
                []
            )

            # --------------------------------------------------------------
            # Console output.
            # --------------------------------------------------------------

            print(
                f"processed @ {detector.fps} FPS | "
                f"user_in_frame={user_in_frame} | "
                f"fall_detected={fall_detected} | "
                f"reasons={fall_reasons}"
            )

            # --------------------------------------------------------------
            # New fall detected.
            # --------------------------------------------------------------

            if detector.should_report_fall(state):

                print()
                print("========================================")
                print("NEW FALL DETECTED")
                print("Now we would be calling MQTT...")
                print("========================================")
                print()

            # --------------------------------------------------------------
            # User disappeared.
            # --------------------------------------------------------------

            # This is only informational for now.
            # We are NOT publishing anything to MQTT.

            if not user_in_frame:

                # Optional debug message.
                pass


    except Exception as e:

        print()
        print("========================================")
        print("ERROR")
        print("========================================")
        print(e)
        print()

    finally:

        # ------------------------------------------------------------------
        # Clean up camera.
        # ------------------------------------------------------------------

        if cap is not None:
            cap.release()

        print("Camera released.")
        print("Program finished.")


if __name__ == "__main__":
    main()
